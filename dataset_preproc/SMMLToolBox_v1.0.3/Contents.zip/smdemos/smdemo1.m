%% SpeechMark Matlab Toolbox Demo #1
% SpeechMark Matlab Toolbox provides tools for locating and displaying landmarks
% in speech
%% Read Sample Wave File
% waveread16k is used to read the sample wave file which contains the word
% "Yes"
[w,fs]=wavread('spx1.wav');
if fs~=16000, error('Example wav file is corrupt.'); end
%% Locate and Display Landmarks
% use mat_vowel_segs to locate and display landmarks

[vsegs,vlms,lms,pt,pv,env,envv,vf,tvv]=...
vowel_segs_full(w(1+0.5*fs:end),fs,maxf0_std('i'),0,'child');
%% Output Matrix

vowel_segments = vsegs
vowel_landmarks = vlms
consonantal_landmarks = lms
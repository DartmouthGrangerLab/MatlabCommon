function varargout = smdemo2(varargin)
% smdemo2 MATLAB code for smdemo2.fig
%      smdemo2, by itself, creates a new smdemo2 or raises the existing
%      singleton*.
%
%      H = smdemo2 returns the handle to a new smdemo2 or the handle to
%      the existing singleton*.
%
%      smdemo2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in smdemo2.M with the given input arguments.
%
%      smdemo2('Property','Value',...) creates a new smdemo2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before smdemo2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to smdemo2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help smdemo2

% Last Modified by GUIDE v2.5 30-Apr-2013 15:15:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @smdemo2_OpeningFcn, ...
                   'gui_OutputFcn',  @smdemo2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% --- Executes just before smdemo2 is made visible.
function smdemo2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to smdemo2 (see VARARGIN)

% Choose default command line output for smdemo2
handles.output = hObject;

% User-Defined Variables
handles.Filespec=[];

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes smdemo2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


%% --- Outputs from this function are returned to the command line.
function varargout = smdemo2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


%% --- Executes on button press in Selectwavpush.
function Selectwavpush_Callback(hObject, eventdata, handles)
% hObject    handle to Selectwavpush (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,Path] = uigetfile('*.wav','All Wave Files (*.wav)');
numchar=38;
handles.Filespec = strcat(Path,FileName);
set(handles.edit1,'String',['...' handles.Filespec(end-numchar:end)]); 
% msgbox(Filespec)
guidata(hObject,handles);

%% --- Executes on selection change in genderpopup.
function genderpopup_Callback(hObject, eventdata, handles)
% hObject    handle to genderpopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns genderpopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from genderpopup


%% --- Executes during object creation, after setting all properties.
function genderpopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to genderpopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% --- Executes on button press in compute_pushbtn.
function compute_pushbtn_Callback(hObject, eventdata, handles)
% hObject    handle to compute_pushbtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

gstring = get(handles.genderpopup,'string');
gvalue = get(handles.genderpopup,'value');
switch gvalue
    case 1
        gender = 'n';
        gfull = 'Neuter';
    case 2
        gender = 'f';
        gfull = 'Female';
    case 3
        gender = 'm';
        gfull = 'Male';
    case 4
        gender = 'i';
        gfull = 'Infant';
    case 5
        gender = 'c';
        gfull = 'Child';
    case 6
        gender = 'e';
        gfull = 'Elderly';
end
% msgbox(num2str(gvalue));
% msgbox(gender);


if ~isempty(handles.Filespec)
    [signal,fs] = wavread(handles.Filespec);
    [N,S]=size(signal); if S>N, signal=signal.'; [N,S]=size(signal); end % Col. vector
    if S>1, signal=signal(:,1); end % Mono
    f = figure(1);
    set(f,'name',strcat(handles.Filespec,' ----  ',gfull),'numbertitle','off')
    vowel_segs_full(signal,fs,maxf0_std(gender),1,[],[]);
else
    warndlg('Please select a valid .wav file','Select File');
end



%%
function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


%% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in play.
function play_Callback(hObject, eventdata, handles)
% hObject    handle to play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Filespec = get(handles.edit1,'string');
TF = isempty(handles.Filespec);
if(TF == 1)
    msgbox('Wavefile not selected')
else
    [signal,fs] = wavread(handles.Filespec);
    sound(signal,fs);    
end

function [ version, builddate ] = smmlt_version()
% Returns versioning information for the SpeechMark Matlab Toolbox

version='1.0.3';
builddate='2016-02-17';
end


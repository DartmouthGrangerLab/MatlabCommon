%  Read properly formatted hard-marked file of specified name.
% 	Syntax: hms = read_hms(HMFNAME)
% 	where 'hms' = structure with fieldnames ".types" [string] and ".times" [numeric: msec].
%

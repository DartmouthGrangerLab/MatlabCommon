function [ version, date ] = smcore_version()
% Returns versioning information for the SpeechMark Core (Matlab) library
% Please update version number and date as per the change(s) in core library

version='2.1.3';
date='2016-02-17';
end
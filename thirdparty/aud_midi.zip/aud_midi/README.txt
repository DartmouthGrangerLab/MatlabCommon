Downloaded by Eli Bowen from:
https://www.mathworks.com/matlabcentral/fileexchange/27470-midi-tools
